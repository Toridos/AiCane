"""
X4 LiDAR Node
시리얼 데이터를 파싱하여 LaserScan 메시지 발행
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
import serial
import struct
import math
from config import LidarConfig


class X4LidarNode(Node):
    def __init__(self):
        super().__init__('lidar_node')
        
        # ROS 발행자
        self.scan_pub = self.create_publisher(LaserScan, '/scan', 10)
        
        # 시리얼 포트 열기
        self.serial = None
        self._init_serial()
        
        # 스캔 데이터 버퍼
        self.ranges = [0.0] * 360
        self.intensities = [0.0] * 360
        
        # 타이머 (연속 읽기)
        self.create_timer(0.01, self.read_lidar)  # 100Hz
        
        self.get_logger().info("✅ LiDAR Node Started")
    
    def _init_serial(self):
        """시리얼 포트 초기화"""
        try:
            self.serial = serial.Serial(
                port=LidarConfig.SERIAL_PORT,
                baudrate=LidarConfig.BAUDRATE,
                timeout=0.5
            )
            self.get_logger().info(f"🔌 LiDAR Connected: {LidarConfig.SERIAL_PORT}")
        except Exception as e:
            self.get_logger().error(f"❌ LiDAR Connection Failed: {e}")
            self.serial = None
    
    def read_lidar(self):
        """
        X4 LiDAR 프로토콜 파싱
        
        X4 패킷 구조 (예시 - 실제 스펙 확인 필요):
        [Header(2B)] [Angle(2B)] [Distance(2B)] [Intensity(1B)] [Checksum(1B)]
        """
        if not self.serial or not self.serial.is_open:
            return
        
        try:
            # 헤더 찾기 (0xAA 0x55 등 - 실제 프로토콜 확인 필요)
            header = self.serial.read(2)
            if len(header) < 2:
                return
            
            # 임시: 더미 데이터 발행 (실제로는 파싱 필요)
            self._publish_dummy_scan()
            
        except Exception as e:
            self.get_logger().warn(f"LiDAR read error: {e}")
    
    def _publish_dummy_scan(self):
        """
        더미 스캔 발행 (실제 파싱 전 테스트용)
        실제로는 X4 프로토콜에 맞춰 파싱해야 함
        """
        msg = LaserScan()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = LidarConfig.FRAME_ID
        
        msg.angle_min = LidarConfig.ANGLE_MIN
        msg.angle_max = LidarConfig.ANGLE_MAX
        msg.angle_increment = (LidarConfig.ANGLE_MAX - LidarConfig.ANGLE_MIN) / 360
        msg.range_min = LidarConfig.RANGE_MIN
        msg.range_max = LidarConfig.RANGE_MAX
        
        # 더미 데이터 (모두 무한대)
        msg.ranges = [float('inf')] * 360
        msg.intensities = [0.0] * 360
        
        self.scan_pub.publish(msg)
    
    def _parse_x4_packet(self, data):
        """
        X4 LiDAR 패킷 파싱 (구현 필요)
        
        TODO: X4 Pro 실제 프로토콜 문서를 보고 구현
        일반적인 구조:
        - Start Byte: 0xAA
        - Packet Type: 0x01~0xFF
        - Angle: 0~360도 (0.01도 단위)
        - Distance: mm 단위
        - Quality/Intensity
        - Checksum
        """
        # 실제 구현 예정
        pass


def main(args=None):
    rclpy.init(args=args)
    node = X4LidarNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node.serial and node.serial.is_open:
            node.serial.close()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

