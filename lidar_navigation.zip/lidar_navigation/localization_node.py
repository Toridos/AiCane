"""
Localization using AMCL (Adaptive Monte Carlo Localization)
라이다 스캔과 사전 맵을 매칭하여 정확한 위치 추정
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose2D, PoseWithCovarianceStamped
from sensor_msgs.msg import LaserScan
import math
import numpy as np
from config import NavigationConfig


class LocalizationNode(Node):
    """
    간단한 Scan Matching 기반 위치 추정
    
    실제 프로젝트에서는 ROS2 Nav2의 AMCL 패키지 사용 권장!
    """
    def __init__(self):
        super().__init__('localization')
        
        # ROS 통신
        self.pose_pub = self.create_publisher(Pose2D, '/pose', 10)
        self.amcl_pose_pub = self.create_publisher(
            PoseWithCovarianceStamped, 
            '/amcl_pose', 
            10
        )
        
        self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)
        
        # 위치 상태
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        
        # 이전 스캔 (ICP용)
        self.prev_scan = None
        
        self.create_timer(0.1, self.publish_pose)
        
        self.get_logger().info("✅ Localization Started (Scan Matching)")
    
    def scan_callback(self, msg):
        """
        라이다 스캔으로 위치 업데이트
        
        간단한 방법: ICP (Iterative Closest Point)
        고급 방법: AMCL, Cartographer 사용
        """
        if self.prev_scan is None:
            self.prev_scan = msg
            return
        
        # TODO: ICP 또는 Scan Matching으로 이동량 계산
        # 현재는 더미 구현
        
        self.prev_scan = msg
    
    def publish_pose(self):
        """현재 위치 발행"""
        msg = Pose2D()
        msg.x = self.x
        msg.y = self.y
        msg.theta = self.theta
        self.pose_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = LocalizationNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()