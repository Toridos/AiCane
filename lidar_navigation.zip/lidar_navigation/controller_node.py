"""
Navigation Controller with LiDAR Obstacle Avoidance
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose2D, Twist, Point
from std_msgs.msg import Bool
from sensor_msgs.msg import LaserScan
import math
import numpy as np
from config import NavigationConfig, LidarConfig


class ControllerNode(Node):
    def __init__(self):
        super().__init__('controller')
        
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.reached_pub = self.create_publisher(Bool, '/goal_reached', 10)
        
        self.create_subscription(Pose2D, '/pose', self.pose_callback, 10)
        self.create_subscription(Point, '/goal', self.goal_callback, 10)
        self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)
        
        self.pose = Pose2D()
        self.goal = None
        self.scan = None
        
        self.create_timer(1.0 / NavigationConfig.CONTROL_HZ, self.control_loop)
        self.get_logger().info("✅ Controller Started (LiDAR-based)")
    
    def pose_callback(self, msg):
        self.pose = msg
    
    def goal_callback(self, msg):
        self.goal = msg
        self.get_logger().info(f"🎯 New goal: ({msg.x:.2f}, {msg.y:.2f})")
    
    def scan_callback(self, msg):
        """라이다 스캔 수신"""
        self.scan = msg
    
    def check_obstacle_ahead(self):
        """
        라이다로 전방 장애물 체크
        
        전방 ±30도 범위 스캔
        """
        if not self.scan:
            return False
        
        ranges = np.array(self.scan.ranges)
        
        # 전방 60도 범위 (±30도)
        front_angles = list(range(0, 30)) + list(range(330, 360))
        
        for angle in front_angles:
            if angle < len(ranges):
                dist = ranges[angle]
                if dist < NavigationConfig.OBSTACLE_THRESHOLD and dist > 0.1:
                    return True
        
        return False
    
    def control_loop(self):
        if not self.goal:
            self._stop()
            return
        
        # 라이다 장애물 체크
        if self.check_obstacle_ahead():
            self.get_logger().warn("⛔ LiDAR Obstacle detected!")
            self._stop()
            return
        
        # Pure Pursuit
        dx = self.goal.x - self.pose.x
        dy = self.goal.y - self.pose.y
        dist = math.sqrt(dx**2 + dy**2)
        
        if dist < NavigationConfig.GOAL_THRESHOLD:
            self.get_logger().info("✅ Goal reached!")
            self._stop()
            self.reached_pub.publish(Bool(data=True))
            self.goal = None
            return
        
        target_angle = math.atan2(dy, dx)
        angle_error = self._normalize_angle(target_angle - self.pose.theta)
        
        cmd = Twist()
        
        if abs(angle_error) > NavigationConfig.ANGLE_TOLERANCE:
            cmd.angular.z = NavigationConfig.KP_ANGULAR * angle_error
        else:
            cmd.linear.x = NavigationConfig.KP_LINEAR * dist
            cmd.angular.z = NavigationConfig.KP_ANGULAR * angle_error
        
        # 속도 제한
        cmd.linear.x = max(-0.3, min(0.3, cmd.linear.x))
        cmd.angular.z = max(-1.0, min(1.0, cmd.angular.z))
        
        self.cmd_pub.publish(cmd)
    
    def _stop(self):
        self.cmd_pub.publish(Twist())
    
    @staticmethod
    def _normalize_angle(angle):
        while angle > math.pi: angle -= 2 * math.pi
        while angle < -math.pi: angle += 2 * math.pi
        return angle


def main(args=None):
    rclpy.init(args=args)
    node = ControllerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()