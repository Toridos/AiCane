"""
# LiDAR Navigation System

## 하드웨어 요구사항
- RobokitRS 메카넘 휠 로봇
- X4 LiDAR 센서
- 라즈베리파이 4

## 설치

### ROS2 패키지 설치
```bash
sudo apt install ros-humble-navigation2
sudo apt install ros-humble-nav2-bringup
sudo apt install ros-humble-slam-toolbox  # SLAM 사용 시
```

### 빌드
```bash
cd ~/ros2_ws
colcon build --packages-select lidar_navigation
source install/setup.bash
```

## 실행

### 1단계: LiDAR 테스트
```bash
ros2 run lidar_navigation lidar_node

# 다른 터미널에서
ros2 topic echo /scan
```

### 2단계: 전체 시스템
```bash
ros2 launch lidar_navigation navigation.launch.py
```

### 3단계: 경로 전송
```bash
# path.json 수정 후
ros2 run lidar_navigation path_manager
```

## ⚠️ 중요: X4 LiDAR 프로토콜 구현 필요

현재 `lidar_node.py`는 더미 데이터만 발행합니다.
실제 X4 Pro LiDAR 프로토콜 문서를 보고 파싱 로직 구현 필요!

참고:
- X4 Pro 데이터시트
- 제조사 SDK
- ROS1 ydlidar 패키지 (참고용)

## SLAM 사용 (선택)

### 맵 생성
```bash
ros2 run slam_toolbox async_slam_toolbox_node

# 로봇 주행하며 맵 생성
# 저장: Ctrl+S
```

### 맵 기반 내비게이션
```bash
# config.py에서 USE_SLAM = False
# MAP_FILE 경로 설정 후 실행
```
"""